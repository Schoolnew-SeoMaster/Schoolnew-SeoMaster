<?php

defined( 'ABSPATH' ) || exit;

class Presscore_Posts_Slider_Scroller {

}