<?php
/**
 * The7 page settings.
 *
 * @package The7
 */

namespace The7\Adapters\Elementor;

use Elementor\Controls_Manager;
use Elementor\Plugin;
use \The7_Post_CSS_Generator;

defined( 'ABSPATH' ) || exit;

class The7_Elementor_Page_Settings {

	/**
	 * Custom Elementor controls.
	 *
	 * @var array $controls Controls array.
	 */
	protected $controls = [];

	/**
	 * Bootstrap calss.
	 */
	public function bootstrap() {
		add_action( 'elementor/documents/register_controls', [ $this, 'add_controls' ] );
		add_filter( 'elementor/editor/localize_settings', [ $this, 'localize_settings' ], 10 );
		add_action( 'elementor/document/after_save', [ $this, 'update_post_meta' ], 10, 2 );
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_editor_scripts' ] );
		add_action( 'elementor/preview/init', [ $this, 'on_elementor_preview_init' ] );
	}

	public function on_elementor_preview_init() {
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'enqueu_editor_preview_scripts' ] );

		$this->maybe_override_post_meta();
	}

	/**
	 * Add 'get_post_metadata' filter that override preview metadata with one from the latest post revision.
	 *
	 * While editing, Elementor creates post reviews and sotre modified data there, but preview post with original
	 * metadata. This little trick allows us to see metadata changes in the preview.
	 */
	public function maybe_override_post_meta() {
		$document = $this->get_document();

		if ( ! $document ) {
			return;
		}

		$document_post_id = $document->get_id();
		$main_post_id     = $document->get_main_id();

		if ( ! $document_post_id || ! $main_post_id ) {
			return;
		}

		add_action(
			'get_post_metadata',
			function ( $meta_value, $object_id, $meta_key, $single ) use ( $document_post_id, $main_post_id ) {
				if ( $object_id !== $main_post_id ) {
					return null;
				}

				if ( $document_post_id !== $object_id && metadata_exists( 'post', $document_post_id, $meta_key ) ) {
					$meta_value = get_post_meta( $document_post_id, $meta_key, $single );

					if ( $single && is_array( $meta_value ) ) {
						$meta_value = [ $meta_value ];
					}

					return $meta_value;
				}

				return null;
			},
			10,
			4
		);
	}

	/**
	 * Add Elementor controls for sidebar, footer and header.
	 *
	 * @param Elementor\Core\Base\Document $document Elementor document class.
	 */
	public function add_controls( $document ) {
		$sections = $this->get_sections( $document->get_name() );

		$this->controls = $this->get_sections_controls( $sections );

		foreach ( $sections as $section_id => $section ) {
			$document->start_controls_section( $section_id, $section['args'] );

			if ( ! empty( $section['controls'] ) ) {
				foreach ( $section['controls'] as $control_id => $control ) {
					if ( isset( $control['args']['options'] ) && is_callable( $control['args']['options'] ) ) {
						$control['args']['options'] = call_user_func( $control['args']['options'] );
					}
					$document->add_control( $control_id, $control['args'] );
				}
			}

			$document->end_controls_section();
		}
	}

	/**
	 * Localize settings values to js front.
	 *
	 * @param array $settings Array of settings.
	 *
	 * @return array
	 */
	public function localize_settings( $settings ) {
		$document = Plugin::$instance->documents->get_doc_or_auto_save( Plugin::$instance->editor->get_post_id() );

		if ( $document && isset( $settings['initial_document']['settings']['settings'] ) ) {
			$post_id = $document->get_post()->ID;
			$page_settings = $settings['initial_document']['settings']['settings'];

			foreach ( $this->controls as $control_id => $control ) {
				if ( isset( $control['on_read'] ) && is_callable( $control['on_read'] ) ) {
					$page_settings[ $control_id ] = call_user_func( $control['on_read'], $control, $document );
					continue;
				}

				if ( isset( $control['meta'] ) && $this->metadata_exists( $post_id, $control['meta'] ) ) {
					$page_settings[ $control_id ] = $document->get_meta( $control['meta'], true );
				}
			}

			$settings['initial_document']['settings']['settings'] = $page_settings;
		}

		return $settings;
	}

	/**
	 * Update post meta.
	 *
	 * @param Elementor\Core\Base\Document $document Elementor document class.
	 * @param array                        $data     Updated settings values.
	 */
	public function update_post_meta( $document, $data ) {
		if ( ! isset( $data['settings'] ) ) {
			return;
		}

		$controls = $this->get_sections_controls( $this->get_sections( $document->get_name() ) );

		foreach ( $controls as $control_id => $control ) {
			$val = isset( $control['args']['default'] ) ? $control['args']['default'] : '';
			if ( isset( $data['settings'][ $control_id ] ) ) {
				$val = $data['settings'][ $control_id ];
			}

			if ( isset( $control['on_save'] ) && is_callable( $control['on_save'] ) ) {
				call_user_func( $control['on_save'], $val, $control, $document );
				continue;
			}

			if ( isset( $control['meta'] ) && is_string( $control['meta'] ) ) {
				$document->update_meta( $control['meta'], $val );
			}
		}

		$post_id = $document->get_post()->ID;

		// Fill revision meta fields from the main post.
		if ( $document->get_post()->post_type === 'revision' ) {
			$post_meta_cache = update_meta_cache( 'post', [ $post_id ] );
			$post_meta_cache = $post_meta_cache[ $post_id ];

			$main_meta_cache = wp_cache_get( $document->get_main_id(), 'post_meta' );
			foreach ( $main_meta_cache as $meta_key => $meta_value ) {
				if ( strpos( $meta_key, '_dt_' ) !== 0 ) {
					continue;
				}

				if ( ! array_key_exists( $meta_key, $post_meta_cache ) ) {
					$post_meta_cache[ $meta_key ] = $meta_value;
				}
			}

			wp_cache_replace( $post_id, $post_meta_cache, 'post_meta' );
		}

		the7_update_post_css( $post_id );
	}

	/**
	 * Add scripts to auto save and reload preview.
	 */
	public function enqueue_editor_scripts() {
		the7_register_style( 'the7-elementor-editor', PRESSCORE_ADMIN_URI . '/assets/css/elementor-editor' );
		wp_enqueue_style( 'the7-elementor-editor' );

		wp_enqueue_script(
			'the7-elementor-page-settings',
			PRESSCORE_ADMIN_URI . '/assets/js/elementor/page-settings.js',
			[],
			THE7_VERSION,
			true
		);

		$controls_ids = [];
		foreach ( $this->controls as $id => $control ) {
			if ( isset( $control['on_change'] ) && $control['on_change'] === 'do_not_reload_page' ) {
				continue;
			}

			$controls_ids[] = $id;
		}

		wp_localize_script(
			'the7-elementor-page-settings',
			'the7Elementor',
			[
				'controlsIds' => $controls_ids,
			]
		);
	}

	/**
	 * Register frontend resources.
	 */
	public function enqueu_editor_preview_scripts() {
		the7_register_style(
			'the7-elementor-editor-preview',
			PRESSCORE_ADMIN_URI . '/assets/css/elementor-editor-preview'
		);
		wp_enqueue_style( 'the7-elementor-editor-preview' );
	}

	/**
	 * @return \Elementor\Core\Base\Document|false
	 */
	public function get_document() {
		return Plugin::$instance->documents->get_doc_for_frontend( get_the_ID() );
	}

	/**
	 * Return page settings definition.
	 *
	 * @return array
	 */
	protected function get_sections( $document_name = '' ) {
		$sections_definition = [
			'the7_document_title_section' => [
				'exclude_documents' => [ 'footer', 'header' ],
				'file'              => 'page-title.php',
			],
			'the7_document_sidebar'       => [
				'exclude_documents' => [ 'footer', 'header' ],
				'file'              => 'sidebar.php',
			],
			'the7_document_footer'        => [
				'exclude_documents' => [ 'footer', 'header' ],
				'file'              => 'footer.php',
			],
			'the7_document_paddings'      => [
				'exclude_documents' => [ 'footer', 'header' ],
				'file'              => 'paddings.php',
			],
			'the7_document_bottom_bar'    => [
				'only_documents' => [ 'footer' ],
				'file'           => 'bottom-bar.php',
			],
		];

		$sections = [];

		foreach ( $sections_definition as $section_id => $section ) {
			if ( $document_name && ! empty ( $section['only_documents'] ) && ! in_array( $document_name, $section['only_documents'] ) ) {
				continue;
			}

			if ( $document_name && ! empty ( $section['exclude_documents'] ) && in_array( $document_name, $section['exclude_documents'] ) ) {
				continue;
			}

			$sections[ $section_id ] = include __DIR__ . "/page-settings/{$section['file']}";
		}

		return $sections;
	}

	/**
	 * @param array $sections
	 *
	 * @return array
	 */
	protected function get_sections_controls( $sections ) {
		$controls = [ [] ];
		foreach ( $sections as $section ) {
			if ( isset( $section['controls'] ) && is_array( $section['controls'] ) ) {
				$controls[] = $section['controls'];
			}
		}

		return array_merge( ...$controls );
	}

	/**
	 * @param $post_id
	 * @param $meta_key
	 *
	 * @return bool
	 */
	protected function metadata_exists( $post_id, $meta_key ) {
		return $post_id && is_string( $meta_key ) && metadata_exists( 'post', $post_id, $meta_key );
	}
}
